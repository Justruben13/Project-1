//In the game, there are numbers spread randomly all over the game-space. You have to arrange them in a proper manner. 
//Play to understand. Please make sure to have graphics.h and conio.h already present on your machine before running.


//Game: Number Sorter


//include relevant libraries
     #include<iostream.h>

       #include<dos.h>

       #include<conio.h>

       #include<graphics.h>

       #include<stdio.h>



       int a[5][5];



       int set[16]={0,4,11,12,7,1,15,5,13,6,10,3,2,14,8,9};


       int DummySet[16]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};


//defining structure, used later on in funcitons and in arrays

       struct pos
     {
       int h,v;
     }position[4][4];

     int row=4,col=4;


        // FUNCTION PROTOTYPES


     void Begins(int); //MOVEMENT


     void Rectangle());   //DRAWING RECTANGLE


     void Prisma());   //PRINTING NUMBERS INITIALLY


     int KeyIsHere();   // TO TRACE KEY PRESSED


     inline void space() { cout<<"    "; }


     inline void print(int r,int c) { cout<<a[r][c]; }


     void coords());   //TO STORE CO-ORDINATES


     int stop();     // STOPING CRITERION


     void DoThisEveryTime(int,int);   //TO PRINT NUMBER IN GAME




//DRIVER FUNCTION



 void main()
{
     int gm=DETECT,gd=DETECT;
     initgraph(&gm,&gd,"");

  int d,WhenToStop=1;
  coords());
  Rectangle());
  Prisma());

   while(WhenToStop!=16)
  {
    d=KeyIsHere();
    Begins(d);
    WhenToStop=stop();
  }

  settextstyle(10,0,1);
  outtextxy(400,300,"Winner!");
  getch();


}






//FUNCTION TO DRAW RECTANGLES





   void Rectangle())
  {
      setcolor(5);

     for(int i=0;i<200;i+=50)
    {
      for(int j=0;j<240;j+=60)
      rectangle(j+100,i+100,j+50,i+60);
    }





//FUNCTION TO PRINT NUMBES INITIALLY




  }

   void Prisma())
  {
      int k=1;
   for(int x=0,i=6;x<4;x++,i+=3)
   {
     for(int y=0,j=10;y<4&&k<16;y++,j+=7,k++)
     {

       gotoxy(position[x][y].h,position[x][y].v);
       cout<<a[x][y];
     }
   }




//FUNCTION TO TRACE THE KEY PRESSED
//USE OF BINARY VARIABLES AND IMPLEMENTATION OF MEMORY ALLOCATION




  }

    int KeyIsHere()
  {
   union REGS i,o;
   while(!kbhit());
    i.h.ah=0;
   int86(22,&i,&o);
    return(o.h.ah);
  }



//FUNCTION TOTO STORE CURRENT COORDINATES



 void coords())
  {
    int k=1;
    for(int x=0,i=6;x<4;x++,i+=3)
   {
     for(int y=0,j=10;y<4;y++,j+=7)
     {
       position[x][y].h=j;
       position[x][y].v=i;
       a[x][y]=set[k++];
     }
   }

  }




//FUNCTION TO START WITH THE GAME




     void Begins(int s)
  {
     int r=row-1;
     int c=col-1;

      if(s==77 &&c!=0)  //right
    {
    col--;

       a[r][c]=a[r][c-1];


     DoThisEveryTime(r,c-1);

     space();

     DoThisEveryTime(r,c);

     print(r,c-1);


    }

      if(s==80 && r!=0)   //down
    {
       row--;

        a[r][c]=a[r-1][c];

      DoThisEveryTime(r-1,c);

       space();

      DoThisEveryTime(r,c);

      print(r-1,c);


    }

        if(s==75 && c!=3)     //left
   {
        a[r][c]=a[r][c+1];
      col++;
      DoThisEveryTime(r,c+1);

      space();


      DoThisEveryTime(r,c);

      print(r,c+1);

   }

      if(s==72 &&r!=3)     //up
   {

      a[r][c]=a[r+1][c];

      row++;

      DoThisEveryTime(r+1,c);

      space();

      DoThisEveryTime(r,c);

      print(r+1,c);


   }

      }




// FUNCTION TO PRINT NUMBER IN THE GAME





  void DoThisEveryTime(int x, int y)
       {
   gotoxy(position[x][y].h,position[x][y].v);
       }




//FUNCTION TO STOP THE GAME




      int stop()
    {
     int k=0,d=1;
       for(int x=0;x<4;x++)
      {
       for(int y=0;y<4;y++)
       {
   if(a[x][y]==DummySet[k])
     d++;

     k++;
  }
      }
       return d;
     }


       
